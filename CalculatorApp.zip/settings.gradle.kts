rootProject.name = "CalculatorApp"
include(":app")
