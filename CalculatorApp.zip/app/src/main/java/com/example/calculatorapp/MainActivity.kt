package com.example.calculatorapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CalculatorApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorApp() {
    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF3F4F6)) {
            CalculatorScreen()
        }
    }
}

@Composable
fun CalculatorScreen() {
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    val history = remember { mutableStateListOf<String>() }

    fun append(char: String) {
        if (char == "." && input.endsWith(".")) return
        input += char
    }

    fun backspace() {
        if (input.isNotEmpty()) input = input.dropLast(1)
    }

    fun clearAll() {
        input = ""
        result = ""
    }

    fun evaluate() {
        try {
            val expr = input.replace('×', '*').replace('÷', '/')
            val value = eval(expr)
            result = value.toString()
            history.add(0, "$input = $result")
        } catch (e: Exception) {
            result = "Error"
        }
    }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {

        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = input.ifEmpty { "0" },
                fontSize = 34.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.End
            )
            Text(
                text = result,
                fontSize = 20.sp,
                color = Color.Gray,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.End
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        val buttons = listOf(
            listOf("7","8","9","÷"),
            listOf("4","5","6","×"),
            listOf("1","2","3","+"),
            listOf(".","0","⌫","-"),
            listOf("C","=")
        )

        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            buttons.forEach { row ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { label ->
                        Box(modifier = Modifier
                            .weight(1f)
                            .height(64.dp)
                            .background(color = Color.White, shape = RoundedCornerShape(12.dp))
                            .clickable {
                                when(label) {
                                    "⌫" -> backspace()
                                    "C" -> clearAll()
                                    "=" -> evaluate()
                                    else -> append(label)
                                }
                            },
                            contentAlignment = Alignment.Center) {
                            Text(text = label, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    if (row.size < 4) {
                        Spacer(modifier = Modifier.weight((4 - row.size).toFloat()))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(text = "History", fontWeight = FontWeight.Bold)
        Column(modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .background(Color(0xFFFFFFFF), shape = RoundedCornerShape(8.dp))
            .padding(8.dp)) {
            if (history.isEmpty()) {
                Text("No history yet", color = Color.Gray)
            } else {
                history.forEach { h -> Text(h) }
            }
        }
    }
}

fun eval(expr: String): Double {
    val tokens = mutableListOf<String>()
    var num = StringBuilder()
    for (c in expr) {
        if (c.isDigit() || c == '.') {
            num.append(c)
        } else if (c == '+' || c == '-' || c == '*' || c == '/') {
            if (num.isNotEmpty()) { tokens.add(num.toString()); num = StringBuilder() }
            tokens.add(c.toString())
        } else if (c.isWhitespace()) {
            continue
        } else {
            throw IllegalArgumentException("Invalid char: $c")
        }
    }
    if (num.isNotEmpty()) tokens.add(num.toString())

    val stack = mutableListOf<String>()
    var i = 0
    while (i < tokens.size) {
        val t = tokens[i]
        if (t == "*" || t == "/") {
            val prev = stack.removeAt(stack.size - 1).toDouble()
            val next = tokens[i+1].toDouble()
            val res = if (t == "*") prev * next else prev / next
            stack.add(res.toString())
            i += 2
        } else {
            stack.add(t)
            i += 1
        }
    }
    var res = stack[0].toDouble()
    i = 1
    while (i < stack.size) {
        val op = stack[i]; val n = stack[i+1].toDouble()
        res = if (op == "+") res + n else res - n
        i += 2
    }
    return res
}
