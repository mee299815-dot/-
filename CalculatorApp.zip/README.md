# CalculatorApp (Jetpack Compose) - Quick Guide (हिन्दी)

यह एक simple calculator Android ऐप है (Jetpack Compose). यह बेसिक arithmetic (+, -, ×, ÷), decimal, clear, backspace और history सपोर्ट करता है।
यह प्रोजेक्ट GitHub पर डालने के बाद included GitHub Actions workflow से APK बन जाएगा और artifacts में उपलब्ध होगा।

## कैसे उपयोग करें
1. ZIP अनज़िप करें और GitHub पर नया repo बनाकर फाइलें अपलोड करें।
2. GitHub Actions workflow ('.github/workflows/android.yml') push पर APK बनाएगा।
3. Actions → Latest run → Artifacts से APK डाउनलोड कर इंस्टॉल करें।

## लोकल बिल्ड
Android Studio में खोलें और Build → Build APK(s) करें।

**नोट:** यह educational/demo प्रोजेक्ट है।
